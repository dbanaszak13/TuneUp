/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuneup;

import java.io.*;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.lang.String;

import com.jfoenix.controls.JFXSlider;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.FileChooser;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.util.*;

/**
 *
 * @author dylanbanaszak
 */
public class FXMLDocumentController implements Initializable {

    DBControl db = new DBControl();

    Media media;
    private MediaPlayer mediaPlayer;


    @FXML
    private JFXSlider volume;

    @FXML
    private TableView<Song> songsList;

    @FXML
    private TableView<User> artistsList;

    @FXML
    private TableColumn<Song, Integer> ID;

    @FXML
    private TableColumn<Song, String> Song, Artist, Genre;

    @FXML
    private TableColumn<Song, Double> Rating;

    @FXML
    private TableColumn<User, String> Username, FName, LName, DOB;

    @FXML
    private TextField textField_search, txt_Artist, txt_SongName, txt_Genre, txt_Description, txt_FilePath, txt_SIUsername, txt_SIPassword, txt_SUUsername, txt_SUPassword, txt_SUFName, txt_SULName, txt_rating;

    @FXML
    private DatePicker dp_SUDOB;

    @FXML 
    private AnchorPane pane_signIn, pane_upload;
    
    @FXML
    private MaterialDesignIconView btn_close, btn_closeSignIn, btn_closeUpload, btn_music, btn_artists, btn_play, btn_pause;
    
    @FXML
    private Button btn_signIn, btn_upload, btn_results, btn_FileBrowser, btn_sUpload, btn_SignIn, btn_SignUp, btn_signOut, btn_remove, btn_rate;

    @FXML
    private Label lbl_userTitle, lbl_userName, lbl_playingArtist, lbl_playingSong;
    
    @FXML
    public void handleButtonAction(MouseEvent event) throws SQLException, IOException, ClassNotFoundException {

        if (event.getSource() == btn_close){
            System.exit(0);
        }
        else{
            if (event.getSource() == btn_signIn){
                pane_signIn.setVisible(true);
            }
            if (event.getSource() == btn_closeSignIn){
                pane_signIn.setVisible(false);
            }
            if (event.getSource() == btn_upload){
                System.out.println(db.getMostRecentSongID());
                pane_upload.setVisible(true);
            }
            if (event.getSource() == btn_closeUpload){
                pane_upload.setVisible(false);
            }
            if (event.getSource() == btn_results){
                String searchInput = textField_search.getText();
                ArrayList<Song> songList = db.searchSong(null, null, searchInput);
                for(int i = 0; i< songList.size()-1; i++){
                    System.out.println(songList.get(i).getName());
                }
                updateSongsList(songList);
            }
            if (event.getSource() == btn_FileBrowser){
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Open Resource File");
                File selectedFile = fileChooser.showOpenDialog(null);
                txt_FilePath.setText(selectedFile.getAbsolutePath());
            }
            if (event.getSource() == btn_sUpload){
                Song uploadSong = new Song(txt_SongName.getText(), txt_Artist.getText(), 0, 0, 0, txt_FilePath.getText(), txt_Genre.getText(), txt_Description.getText());
                db.addSong(uploadSong);
                db.addMp3(db.getMostRecentSongID(), txt_FilePath.getText());
                txt_SongName.clear();
                txt_Genre.clear();
                txt_Description.clear();
                txt_Artist.clear();
                txt_FilePath.clear();
                updateSongsList(db.getSongsList());
                pane_upload.setVisible(false);
            }
            if (event.getSource() == btn_SignIn){
                User loginUser = new User(txt_SIUsername.getText(), "", txt_SIPassword.getText(), "", "", "");
                String message = db.userLogin(loginUser);
                if(message.equals("This user doesn't exist")){
                    txt_SIUsername.setText("This user doesn't exist.");
                } else if (message.equals("Logged in as user!!")){
                    System.out.println("Logged in!!");
                    pane_signIn.setVisible(false);
                    btn_upload.setVisible(true);
                    btn_signIn.setVisible(false);
                    btn_signOut.setVisible(true);
                    lbl_userTitle.setText("User:");
                    lbl_userName.setText(txt_SIUsername.getText());
                    txt_SIPassword.clear();
                    txt_SIUsername.clear();
                }  else if (message.equals("Logged in as admin!!")){
                    System.out.println("Logged in!!");
                    pane_signIn.setVisible(false);
                    btn_upload.setVisible(true);
                    btn_signIn.setVisible(false);
                    btn_signOut.setVisible(true);
                    btn_remove.setVisible(true);
                    lbl_userTitle.setText("Admin:");
                    lbl_userName.setText(txt_SIUsername.getText());
                    txt_SIPassword.clear();
                    txt_SIUsername.clear();
                } else if(message.equals("Incorrect Password entered")){
                    txt_SIUsername.setText("Incorrect Password");
                }

            }

            if(event.getSource() == btn_signOut){
                lbl_userName.setText("");
                lbl_userTitle.setText("Guest");
                btn_signOut.setVisible(false);
                btn_signIn.setVisible(true);
                btn_upload.setVisible(false);
                btn_remove.setVisible(false);
            }

            if(event.getSource() == btn_SignUp){
                User signUpUser = new User(txt_SUUsername.getText(), "User", txt_SUPassword.getText(), txt_SUFName.getText(),txt_SULName.getText(), dp_SUDOB.getValue().toString());
                db.addUser(signUpUser);
                txt_SUFName.clear();
                txt_SULName.clear();
                txt_SUPassword.clear();
                txt_SUUsername.clear();
                pane_signIn.setVisible(false);
                updateUsersList(db.getUserList());
                System.out.println("Added User");

            }

            if (event.getSource() == songsList){

                if(mediaPlayer != null) {
                    mediaPlayer.pause();
                    mediaPlayer = null;
                }
                btn_play.setStyle("-fx-fill: black;");
                btn_pause.setStyle("-fx-fill: black;");
                if(lbl_userTitle.getText().equals("Admin")) {
                    btn_remove.setVisible(true);
                }
                lbl_playingArtist.setText("Artist");
                lbl_playingSong.setText("Song");
                Song current = songsList.getSelectionModel().getSelectedItem();
                db.getMp3(current.getSongID());
            }

            if(event.getSource() == artistsList){
                if(lbl_userTitle.getText().equals("Admin")) {
                    btn_remove.setVisible(true);
                }
            }

            if (event.getSource() == btn_artists){
                songsList.setVisible(false);
                artistsList.setVisible(true);
                updateUsersList(db.getUserList());

            }
            if (event.getSource() == btn_music){
                artistsList.setVisible(false);
                songsList.setVisible(true);
                updateSongsList(db.getSongsList());
            }

            if (event.getSource() == btn_play){
                //mediaPlayer = new MediaPlayer(media);
                //mediaPlayer.seek(length);
                if(mediaPlayer == null) {
                    media = new Media(new File("tmp.mp3").toURI().toString());
                    mediaPlayer = new MediaPlayer(media);
                }
                mediaPlayer.play();
                Song current = songsList.getSelectionModel().getSelectedItem();
                lbl_playingArtist.setText(current.getArtist());
                lbl_playingSong.setText(current.getName());
                btn_play.setStyle("-fx-fill: green;");
                btn_pause.setStyle("-fx-fill: black;");

            }
            if (event.getSource() == btn_pause){
                //mediaPlayer = new MediaPlayer(media);
                if(mediaPlayer != null) {
                    mediaPlayer.pause();
                }
                btn_pause.setStyle("-fx-fill: green;");
                btn_play.setStyle("-fx-fill: black;");
                //length = getCurrentPosition(media);
            }
            if (event.getSource() == volume){
                if (volume.isValueChanging()){
                    mediaPlayer.setVolume(volume.getValue()/100.0);
                }
            }

            if(event.getSource() == btn_rate){
                int rating = Integer.parseInt(txt_rating.getText());
                if(rating <= 5) {
                    Song current = songsList.getSelectionModel().getSelectedItem();
                    Song editSongRating = db.getSong(current.getSongID());
                    db.editRating(editSongRating, rating);
                    txt_rating.setText("");
                    updateSongsList(db.getSongsList());
                }
                else{
                    txt_rating.setText("5");
                }
            }

            if(event.getSource() == btn_remove){
                if(songsList.isVisible() == true){
                    Song current = songsList.getSelectionModel().getSelectedItem();
                    db.deleteSong(current.getSongID());
                    updateSongsList(db.getSongsList());
                }
                else if (artistsList.isVisible() == true){
                    User current = artistsList.getSelectionModel().getSelectedItem();
                    db.deleteUser(current.getUsername());
                    updateUsersList(db.getUserList());
                }
                btn_remove.setVisible(true);

            }

        }

    }

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        try {
            db.setConnections();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        artistsList.setVisible(false);
        songsList.setVisible(true);
        try {
            updateSongsList(db.getSongsList());
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void updateSongsList(ArrayList<Song> listSong){
        for(int i = 0; i < songsList.getItems().size(); i++) {
            songsList.getItems().clear();
        }
        final ObservableList<Song> data = FXCollections.observableArrayList(
                listSong
        );

        ID.setCellValueFactory(new PropertyValueFactory<Song, Integer>("songID"));

        Song.setCellValueFactory(new PropertyValueFactory<Song, String>("name"));

        Artist.setCellValueFactory(new PropertyValueFactory<Song, String>("artist"));

        Genre.setCellValueFactory(new PropertyValueFactory<Song, String>("genre"));

        Rating.setCellValueFactory(new PropertyValueFactory<Song, Double>("rating"));

        songsList.setItems(data);

    }

    public void updateUsersList(ArrayList<User> listUser){
        for(int i = 0; i < artistsList.getItems().size(); i++){
            artistsList.getItems().clear();
        }
        final ObservableList<User> data = FXCollections.observableArrayList(
          listUser
        );

        Username.setCellValueFactory(new PropertyValueFactory<User, String>("username"));

        FName.setCellValueFactory(new PropertyValueFactory<User, String>("firstName"));

        LName.setCellValueFactory(new PropertyValueFactory<User, String>("lastName"));

        DOB.setCellValueFactory(new PropertyValueFactory<User, String>("dateOfBirth"));

        artistsList.setItems(data);

    }

    
}
